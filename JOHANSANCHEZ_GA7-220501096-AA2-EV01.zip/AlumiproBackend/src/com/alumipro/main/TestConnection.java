package com.alumipro.main;

import com.alumipro.config.DatabaseConnection;

public class TestConnection {
    public static void main(String[] args) {
        DatabaseConnection.getConnection();
    }
}